package ch05_api_java_18_21.ch05_01_reflection;

import java.lang.invoke.MethodHandles;
import java.util.*;

/**
 * Beispielprogramm für die Workshops "Best of Java 11/17 bis 20/21/22/23/24/25" / die Bücher "Java – die Neuerungen in Java 17 LTS, 18 und 19" und "Java 25 LTS"
 * Sample program for the workshops "Best of Java 11/17 to 20/21/22/23/24/25" / the books “Java – the new features in Java 17 LTS, 18, and 19” and “Java 25 LTS and Beyond”
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/25/26 by Michael Inden
 */
public class ReflectionExample {
    public static void main(final String[] args) throws ReflectiveOperationException {
        Locale.setDefault(Locale.US);
        accessFieldOldStyle("Java 21 LTS Rocks");
        accessFieldNewStyle("Java 21 LTS Rocks");
    }

    private static void accessFieldOldStyle(final String input) throws ReflectiveOperationException {
        var field = String.class.getDeclaredField("value");
        field.setAccessible(true);

        System.out.println(Arrays.toString((byte[]) field.get(input)));
    }

    private static void accessFieldNewStyle(final String input) throws ReflectiveOperationException {
        var lookup = MethodHandles.privateLookupIn(String.class,
                MethodHandles.lookup());
        var handle = lookup.findVarHandle(String.class, "value", byte[].class);

        System.out.println(Arrays.toString((byte[]) handle.get(input)));
    }
}