package ch09_syntax_java_22_25.jep511_module_import_declarations;

import java.util.List;
import java.util.stream.Stream;
// unsupported in IntelliJ 2024.1.2 Preview
/*
import java.util.List;
import java.util.stream.Stream;
import java.io.IO;
*/

/**
 * Beispielprogramm für die Workshops "Best of Java 11/17 bis 20/21/22/23/24/25" / die Bücher "Java – die Neuerungen in Java 17 LTS, 18 und 19" und "Java 25 LTS"
 * Sample program for the workshops "Best of Java 11/17 to 20/21/22/23/24/25" / the books “Java – the new features in Java 17 LTS, 18, and 19” and “Java 25 LTS and Beyond”
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/25/26 by Michael Inden
 */
public class ModuleImportExample2 {
    void main() {
        List<String> result = Stream.of("AB", "BC", "CD", "DE").
                filter(str -> str.contains("C")).
                toList();
        System.out.println(result);

        IO.print("New Style IO");
    }
}