package ch09_syntax_java_22_25.jep507_primitive_types_in_patterns;

public class EnhancementDominanceCheck {

    /*
    static void main() {

        int i1 = 1_000_000_000;
        switch (i1) {
            case float f -> {
                IO.println("float " + f);
            }
            case 16_777_216 -> {
                IO.println("Special constant");
            }
            default -> {
                IO.println("Some default processing");
            }
        }

        int someValue = 4711;
        switch (someValue) {
            case int i -> {
                IO.println("int " + i);
            }
            case float f -> {
                IO.println("float " + f);
            }
        }

        byte b = 42;
        switch (b) {
            case short s -> {
                IO.println("short " + s);
            }
            case 42 -> {
                IO.println("The answer is 42!");
            }
        }
    }
     */
}
