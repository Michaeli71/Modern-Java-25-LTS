package ch11_jvm_java_22_25.jep512_compact_source_files;

/**
 * Beispielprogramm für die Workshops "Best of Java 11/17 bis 20/21/22/23/24/25" / die Bücher "Java – die Neuerungen in Java 17 LTS, 18 und 19" und "Java 25 LTS"
 * Sample program for the workshops "Best of Java 11/17 to 20/21/22/23/24/25" / the books “Java – the new features in Java 17 LTS, 18, and 19” and “Java 25 LTS and Beyond”
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024/25/26 by Michael Inden
 */
class InstanceMainMethodExample {
    void main() {
        System.out.println("InstanceMainMethodExample");
    }

    static void main(final String[] args) {
        System.out.println("Static main");
    }
}
